// Toggle del menú
function toggleMenu() {
  const sidebar = document.getElementById("sidebar");
  const overlay = document.getElementById("overlay");
  sidebar.classList.toggle("open");
  overlay.classList.toggle("show");
}

// Cerrar menú
function closeMenu() {
  const sidebar = document.getElementById("sidebar");
  const overlay = document.getElementById("overlay");
  sidebar.classList.remove("open");
  overlay.classList.remove("show");
}

// Detectar deslizamiento hacia la izquierda para cerrar el menú
let touchStartX = 0;
let touchEndX = 0;

function handleTouchStart(e) {
  touchStartX = e.changedTouches[0].screenX;
}

function handleTouchEnd(e) {
  touchEndX = e.changedTouches[0].screenX;
  handleGesture();
}

function handleGesture() {
  if (touchStartX - touchEndX > 50) {
    closeMenu();
  }
}

document.addEventListener('touchstart', handleTouchStart, false);
document.addEventListener('touchend', handleTouchEnd, false);

// Cerrar menú si se hace click en un link
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('#sidebar a').forEach(link => {
    link.addEventListener('click', () => {
      closeMenu();
    });
  });
});
